<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TranskipNilai extends Model
{
    use HasFactory;
    protected $fillable = [
        'hasil_studi_id','tahun_ajar_id','user_id',
    ];

    public function hasil_studi() {
        return $this->belongsTo(HasilStudi::class);
    }
    public function tahun_ajar() {
        return $this->belongsTo(TahunAjar::class);
    }
}
