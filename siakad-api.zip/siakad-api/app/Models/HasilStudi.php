<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HasilStudi extends Model
{
    use HasFactory;

    protected $fillable =[
        'kode_matkul','nama_matkul','sks',
        'nilai','angka_kumulatif',
        'tahun_ajar_id','user_id',
    ];

    public function tahun_ajar() {
        return $this->belongsTo(TahunAjar::class);
    }
    public function transkip_nilai() {
        return $this->hasOne(TranskipNilai::class);
    }
}
