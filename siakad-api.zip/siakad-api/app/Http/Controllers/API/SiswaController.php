<?php

namespace App\Http\Controllers\API;

use App\Models\User;
use App\Models\Tagihan;
use App\Models\Fakultas;
use App\Models\Mengajar;
use App\Models\Presensi;
use App\Models\ListBiaya;
use App\Models\TahunAjar;
use App\Models\Matakuliah;
use App\Models\JadwalKuliah;
use Illuminate\Http\Request;
use App\Models\KartuStudiTetap;
use App\Models\RegistrasiUlang;
use App\Models\RequestMatakuliah;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Models\RegistrasiMatakuliah;

class SiswaController extends Controller
{
    public function profileSiswa(Request $request) {
        $tahun_ajar = TahunAjar::firstWhere('id', auth()->user()->tahun_ajar_id);
        $hs = auth()->user()->transkip_nilai;
        $total_beban_sks = 0;

        foreach ($hs as $var) {
            $total_beban_sks += $var->hasil_studi->sks;
        }

        return response()->json([
            'nama_siswa' => auth()->user()->nama_siswa,
            'nim' => auth()->user()->nim,
            'semester' => $tahun_ajar->semester,
            'tahun_ajar' => $tahun_ajar->tahun_ajar,
            'email' => auth()->user()->email,
            'beban_sks' => auth()->user()->beban_sks,
            'nik' => auth()->user()->nik,
            'no_hp' => auth()->user()->no_hp,
            'no_kk' => auth()->user()->no_kk,
            'fakultas' => auth()->user()->fakultas->nama_fakultas,
            'program_studi' => auth()->user()->fakultas->program_studi,
            'total_beban_sks' => $total_beban_sks,
        ]);
    }

    public function updateProfileBeranda(Request $request) {
        auth()->user()->update([
            'no_hp' => $request->no_hp,
            'email' => $request->email,
            'no_kk' => $request->no_kk,
            'nik' => $request->nik,
        ]);

        return ['msg' => 'Berhasil mengupdate..!'];
    }
    
    public function statusRegistrasiUlang() {
        $regisUlangSiswa = auth()->user()->registrasi_ulang->where('semester', auth()->user()->tahun_ajar->semester)
        ->firstWhere('tahun_ajar', auth()->user()->tahun_ajar->tahun_ajar);

        $waktuSekarang = date('Y-m-d', time());

        if($waktuSekarang < $regisUlangSiswa->waktu_mulai) {
            return ['kondisi' => 0];
        } else {
            if($waktuSekarang > $regisUlangSiswa->waktu_berakhir) {
                return [
                    'kondisi' => 1,
                    'status' => 1,
                ];
            } else {
                if($regisUlangSiswa->status ==  0) {
                    return [
                        'kondisi' => 1,
                        'status' => 0,
                    ];
                } else {
                    return [
                        'kondisi' => 1,
                        'status' => 1,
                    ];
                }
            }
        }
    }

    public function registrasiUlang(Request $request) {
        if($request->jenis_registrasi != 'KULIAH' || $request->jenis_registrasi != 'ULANG') {
            $tahun_ajar = TahunAjar::firstWhere('id', auth()->user()->tahun_ajar_id);
            RegistrasiUlang::where('user_id', auth()->user()->id)->where('semester', $tahun_ajar->semester)->where('tahun_ajar', $tahun_ajar->tahun_ajar)
            ->update([
                'jenis_registrasi' => $request->jenis_registrasi,
                'status' => '1',
            ]);
            
            return ['success' => 'Berhasil Registrasi Ulang'];
        } else {
            return ['failed' => 'Gagal Registrasi Ulang'];
        }
    }

    public function kartuStudiSiswa() {
        $kst = auth()->user()->kartu_studi_tetap;
        $mengajar = $kst->pluck('mengajar_id')->toArray();
        $bu = $kst->pluck('b/u')->toArray();
        
        $data = [
            'id' => auth()->user()->kartu_studi_tetap->pluck('id')->toArray(),
            'bu'=> $bu,'hari_kuliah' => array(),
            'jam_kuliah' => array(),'dosen' => array(),
            'kode_dosen' => array(),'matkul' => array(),
            'kode_matkul' => array(),'sksa' => array(),
            'sksb' => array(),'ruangan' => array(),
        ];
        foreach ($mengajar as $var) {
            array_push($data['hari_kuliah'], Mengajar::firstWhere('id', $var)->hari_kuliah);
            array_push($data['jam_kuliah'], Mengajar::firstWhere('id', $var)->jam_kuliah);
            array_push($data['dosen'], Mengajar::firstWhere('id', $var)->dosen->nama_dosen);
            array_push($data['kode_dosen'], Mengajar::firstWhere('id', $var)->dosen->nid);
            array_push($data['matkul'], Mengajar::firstWhere('id', $var)->matakuliah->nama_matkul);
            array_push($data['kode_matkul'], Mengajar::firstWhere('id', $var)->matakuliah->kode_matkul.Mengajar::firstWhere('id', $var)->matakuliah->kode_huruf);
            array_push($data['sksa'], Mengajar::firstWhere('id', $var)->matakuliah->sks_a);
            array_push($data['sksb'], Mengajar::firstWhere('id', $var)->matakuliah->sks_b);
            array_push($data['ruangan'], Mengajar::firstWhere('id', $var)->ruangan->nomor_ruangan);
        }
        
        return $data;
    }

    public function statusRegistrasiMatakuliah() {
        $regisMatkul = RegistrasiMatakuliah::firstWhere('fakultas_id', auth()->user()->fakultas_id);
        $tagihan = auth()->user()->tagihan->firstWhere('tahun_ajar_id', auth()->user()->tahun_ajar_id);
        $waktuSekarang = date('Y-m-d h:i:s', time());

        if($regisMatkul->waktu_mulai < $waktuSekarang) {
            if($regisMatkul->waktu_berakhir < $waktuSekarang) {
                return ['kondisi' => 1, 'status' => 0];
            } else {
                if($tagihan->harus_dibayar == 0) {
                    return ['kondisi' => 1, 'status' => 1];
                } else {
                    return ['kondisi' => 0];
                }
            }  
        }else {
            return ['kondisi' => 0];       
        }
    }

    public function jadwalKuliah() {
        $count = 0;
        $kst = auth()->user()->kartu_studi_tetap->where('tahun_ajar_id', auth()->user()->tahun_ajar_id);
        $mengajar = $kst->pluck('mengajar_id')->toArray();

        $data = [
            'id' => array(),'hari_kuliah' => array(),
            'jam_kuliah' => array(),'dosen' => array(),
            'kode_dosen' => array(),'ruangan' => array(),
            'matkul' => array(),'kode_matkul' => array(),
            'kehadiran' => array(),'total_kehadiran' => array(),
        ];

        foreach($mengajar as $var) {
            array_push($data['id'], $kst->skip($count)->first()->jadwal_kuliah->id);
            array_push($data['hari_kuliah'], Mengajar::firstWhere('id', $var)->hari_kuliah);
            array_push($data['jam_kuliah'], Mengajar::firstWhere('id', $var)->jam_kuliah);
            array_push($data['dosen'], Mengajar::firstWhere('id', $var)->dosen->nama_dosen);
            array_push($data['kode_dosen'], Mengajar::firstWhere('id', $var)->dosen->nid);
            array_push($data['matkul'], Mengajar::firstWhere('id', $var)->matakuliah->nama_matkul);
            array_push($data['kode_matkul'], Mengajar::firstWhere('id', $var)->matakuliah->kode_matkul.Mengajar::firstWhere('id', $var)->matakuliah->kode_huruf);
            array_push($data['ruangan'], Mengajar::firstWhere('id', $var)->ruangan->nomor_ruangan);
            array_push($data['kehadiran'], $kst->skip($count)->first()->jadwal_kuliah->presensi->where('jam_masuk','<>','')->count());
            array_push($data['total_kehadiran'], $kst->skip($count)->first()->jadwal_kuliah->presensi->count('jam_masuk'));
            $count++;
        }
        return $data;
    }

    public function registrasiMatakuliah() {

        $matakuliah = Matakuliah::all()->unique('kode_matkul')->pluck('id')->toArray();

        $data = [
            'id' => array(),'kode_matkul' => array(),
            'nama_matkul' => array(),'jumlah_sks' => array(),
        ];

        foreach ($matakuliah as $var) {
            array_push($data['id'], Matakuliah::firstWhere('id', $var)->id);
            array_push($data['kode_matkul'], Matakuliah::firstWhere('id', $var)->kode_matkul);
            array_push($data['nama_matkul'], Matakuliah::firstWhere('id', $var)->nama_matkul);
            array_push($data['jumlah_sks'], Matakuliah::firstWhere('id', $var)->jumlah_sks);
        }

       return $data;
    }

    public function registrasiMatakuliahDalam(Request $request) {
        $matkul = Matakuliah::where('kode_matkul', $request->kodeMK)->pluck('id')->toArray();

        $data = [
            'nama_matkul' => Matakuliah::firstWhere('id', $matkul[0])->nama_matkul,
            'id' => array(),'hari_kuliah' => array(),
            'jam_kuliah' => array(),'kursi_terpilih' => array(),
            'kursi_tersedia' => array(),'nama_dosen' => array(),
            'kode_matkul' => array(),'kode_huruf' => array(),
            'ruangan' => array(),
        ];

        foreach ($matkul as $var) {
            array_push($data['id'], Mengajar::firstWhere('matakuliah_id', $var)->id);
            array_push($data['hari_kuliah'], Mengajar::firstWhere('matakuliah_id', $var)->hari_kuliah);
            array_push($data['jam_kuliah'], Mengajar::firstWhere('matakuliah_id', $var)->jam_kuliah);
            array_push($data['kursi_terpilih'], Mengajar::firstWhere('matakuliah_id', $var)->kursi_terpilih);
            array_push($data['kursi_tersedia'], Mengajar::firstWhere('matakuliah_id', $var)->kursi_tersedia);
            array_push($data['nama_dosen'], Mengajar::firstWhere('matakuliah_id', $var)->dosen->nama_dosen);
            array_push($data['kode_matkul'], Mengajar::firstWhere('matakuliah_id', $var)->matakuliah->kode_matkul);
            array_push($data['kode_huruf'], Mengajar::firstWhere('matakuliah_id', $var)->matakuliah->kode_huruf);
            array_push($data['ruangan'], Mengajar::firstWhere('matakuliah_id', $var)->ruangan->nomor_ruangan);

        }
        return $data;
    }

    public function kelasPilihan(Request $request) {

        if($request->totalSks >= auth()->user()->beban_sks) {
            return ['msg'=>'Tidak bisa mengambil matakuliah lagi, karena telah melebihi batas beban sks'];
        }

        $kode_mk = array();
        $kst = auth()->user()->kartu_studi_tetap->all();
        foreach ($kst as $var) {
            array_push($kode_mk, $var->mengajar->matakuliah->kode_matkul);
        }

        if(in_array(Mengajar::find($request->id)->matakuliah->kode_matkul, $kode_mk)) {
            return ['msg' => 'Matakuliah telah diambil'];
        }

        if(Mengajar::find($request->id)->kursi_tersedia == Mengajar::find($request->id)->kursi_terpilih){
            return ['msg' => 'Matakuliah Sudah Penuh'];
        }

        Mengajar::find($request->id)->update([
            'kursi_terpilih' => DB::raw('kursi_terpilih+1'),
        ]);
        $kst = KartuStudiTetap::create([
            'b/u' => 'b',
            'mengajar_id' => $request->id,
            'user_id' => auth()->user()->id,
            'tahun_ajar_id' => auth()->user()->tahun_ajar_id,
        ]);

        JadwalKuliah::create([
            'user_id' => auth()->user()->id,
            'kartu_studi_tetap_id' => $kst->id,
        ]);

        return ['msg' => 'Berhasil mengambil kelas..!'];
    }

    public function hapusKelas(Request $request) {
        $kst = KartuStudiTetap::find($request->id);
        Mengajar::find($kst->mengajar->id)->update([
            'kursi_terpilih' => DB::raw('kursi_terpilih-1'),
        ]);
        JadwalKuliah::firstWhere('kartu_studi_tetap_id', $kst->id)->delete();
        $kst->delete();

        return ['msg' => 'Berhasil Menghapus Kelas'];
    }

    public function cetakKST() {
        $mengajar_id_list = auth()->user()->kartu_studi_tetap->pluck('mengajar_id')->toArray();
        $mengajar = Mengajar::all()->whereIn('id', $mengajar_id_list);
        
        $pdf = PDF::loadview('cetak-kst', [
            'kst' => auth()->user()->kartu_studi_tetap->pluck('b/u')->toArray(),
            'mengajar' => $mengajar,
        ])->setPaper('a3', 'potrait');
        
        return $pdf->download('kst.pdf');
    }

    public function tagihanSiswa() {
        return auth()->user()->tagihan;
    }

    public function cetakTagihan() {
        $tahun_ajar_id = auth()->user()->tahun_ajar->id;
        $tagihan = Tagihan::firstWhere('tahun_ajar_id', $tahun_ajar_id);

        $pdf = PDF::loadview('cetak-tagihan', [
            'tagihan' => $tagihan,
            'harga_sks' => ListBiaya::first()->harga_sks,
        ])->setPaper('a4', 'potreit');

        return $pdf->download('tagihan.pdf');
    }

    public function presensiSiswa(Request $request) {
        $presensi = auth()->user()->jadwal_kuliah->firstWhere('id', $request->id)->presensi;
        
        $data = [
            'nama_matkul' => auth()->user()->jadwal_kuliah->firstWhere('id', $request->id)->kartu_studi_tetap->mengajar->matakuliah->nama_matkul,
            'id' => array(),'nama_pertemuan' => array(),
            'link_meet' => array(),'link_materi' => array(),
            'jam_masuk' => array(),'rps_materi' => array(),
        ];

        foreach($presensi as $var) {
            array_push($data['id'], $var->id);
            array_push($data['nama_pertemuan'], $var->nama_pertemuan);
            array_push($data['link_meet'], $var->link_meet);
            array_push($data['link_materi'], $var->link_materi);
            array_push($data['jam_masuk'], $var->jam_masuk);
            array_push($data['rps_materi'], $var->rps_materi);
        }
        return $data;
    }

    public function presensiHadir(Request $request) {
        if(Presensi::firstWhere('id', $request->id)->status != 1) {
            return ['msg' => 'Absen tidak dibuka..!!'];
        } else {
            setlocale(LC_ALL, 'IND');
            Presensi::firstWhere('id', $request->id)
            ->update([
                'jam_masuk' => strftime("%e %b %Y, %X"),
            ]);
            return ['msg'=>'success'];
        }
    }

    public function hasilStudi() {
        $data = [
            'kode_matkul' => array(),'nama_matkul' => array(),
            'sks' => array(),'nilai' => array(),
            'angka_kumulatif' => array(),'total_sks' => 0,
            'total_ak' => 0,'ips' => 0,
        ];
        $hs = auth()->user()->hasil_studi->where('tahun_ajar_id', auth()->user()->tahun_ajar_id);
        $totalSks = 0;
        $totalAK = 0;
        foreach ($hs as $var) {
            array_push($data['kode_matkul'], $var->kode_matkul);
            array_push($data['nama_matkul'], $var->nama_matkul);
            array_push($data['sks'], $var->sks);
            array_push($data['nilai'], $var->nilai);
            array_push($data['angka_kumulatif'], $var->angka_kumulatif);
            $totalAK += $var->angka_kumulatif;
            $totalSks += $var->sks;
        }

        $data['total_sks'] = $totalSks;
        $data['total_ak'] = $totalAK;
        $data['ips'] = $totalAK/$totalSks;
        
        return $data;
    }

    public function transkipSiswa() {
        $data = [
            'kode_matkul' => array(),'nama_matkul' => array(),
            'sks' => array(),'nilai' => array(),
            'ak' => array(),'tahun_ambil' => array(),
            'totalSks' => array(), 'totalAK' => array(),
            'ipk' => 0.0,
        ];

        $totalSks = 0;
        $totalAK = 0;
        $tahun_ajar = auth()->user()->tahun_ajar;
        $transkip = auth()->user()->transkip_nilai;
        
        foreach ($transkip as $var) {
            array_push($data['kode_matkul'], $var->hasil_studi->kode_matkul);
            array_push($data['nama_matkul'], $var->hasil_studi->nama_matkul);
            array_push($data['sks'], $var->hasil_studi->sks);
            array_push($data['nilai'], $var->hasil_studi->nilai);
            array_push($data['ak'], $var->hasil_studi->angka_kumulatif);
            array_push($data['tahun_ambil'], $tahun_ajar->tahun_ajar.'/'.$tahun_ajar->semester);
            $totalAK += $var->hasil_studi->angka_kumulatif;
            $totalSks += $var->hasil_studi->sks;
        }

        $data['total_sks'] = $totalSks;
        $data['total_ak'] = $totalAK;
        $data['ipk'] = $totalAK/$totalSks;
        return $data;
    }

    public function requestMatkul(Request $request) {
        RequestMatakuliah::create([
            'nama_siswa' => auth()->user()->nama_siswa,
            'nim' => auth()->user()->nim,
            'kode_matkul' => $request->kode_matkul,
            'nama_matkul' => $request->nama_matkul,
            'alasan' => $request->alasan,
        ]);
        return ['msg' => 'Berhasil mengirim request..!'];
    }
}