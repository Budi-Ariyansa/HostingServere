<?php

namespace App\Http\Controllers\API;

use Validator;
use App\Models\User;
use App\Models\Dosen;
use App\Models\Riwayat;
use App\Models\Mengajar;
use App\Models\Presensi;
use Illuminate\Http\Request;
use App\Models\KartuStudiTetap;
use App\Http\Controllers\Controller;

class DosenController extends Controller
{
    public function profileDosen(Request $request) {
        return auth()->user();
    }

    public function jadwalDosen() {
        $jadwal = auth()->user()->mengajar->pluck('id');

        $data = [
            'id' => $jadwal,
            'hari_kuliah' => array(),
            'jam_kuliah' => array(),
            'ruangan' => array(),
            'matkul' => array(),
            'kode_matkul' => array(),
        ];

        foreach($jadwal as $var) {
            array_push($data['hari_kuliah'], Mengajar::firstWhere('id', $var)->hari_kuliah);
            array_push($data['jam_kuliah'], Mengajar::firstWhere('id', $var)->jam_kuliah);
            array_push($data['matkul'], Mengajar::firstWhere('id', $var)->matakuliah->nama_matkul);
            array_push($data['kode_matkul'], Mengajar::firstWhere('id', $var)->matakuliah->kode_matkul.Mengajar::firstWhere('id', $var)->matakuliah->kode_huruf);
            array_push($data['ruangan'], Mengajar::firstWhere('id', $var)->ruangan->nomor_ruangan);
        }
        return $data;
    }

    public function listPresensi(Request $request) {
        $presensi = KartuStudiTetap::firstWhere('mengajar_id', $request->id)->jadwal_kuliah->presensi;
        $data = [
            'nama_matkul' => Mengajar::find($request->id)->matakuliah->nama_matkul,
            'nama_pertemuan' => array(),
            'link_meet' => array(),
            'link_materi' => array(),
            'rps_materi' => array(),
        ];

        foreach($presensi as $var) {
            array_push($data['nama_pertemuan'], $var->nama_pertemuan);
            array_push($data['link_meet'], $var->link_meet);
            array_push($data['link_materi'], $var->link_materi);
            array_push($data['rps_materi'], $var->rps_materi);
        }
        return $data;
    }
    
    public function buatPresensi(Request $request) {
        $validator = Validator::make($request->all(),[
            'nama_pertemuan' => 'required|string',
            'rps_materi' => 'required|string',
            'link_meet' => 'required|string',
            'link_materi' => 'required|string',
        ]);

        if($validator->fails()){
            return response()->json($validator->errors());       
        }
        
        $kst = auth()->user()->mengajar->find($request->id)->kartu_studi_tetap;
        
        for ($i=0; $i < $kst->count(); $i++) { 
            $jadwal_id = $kst->skip($i)->first()->jadwal_kuliah->id;

            $presensi = Presensi::create([
                'nama_pertemuan' => $request->nama_pertemuan,
                'rps_materi' => $request->rps_materi, 
                'link_meet' => $request->link_meet,
                'link_materi' => $request->link_materi,
                'jadwal_kuliah_id' => $jadwal_id,
                'mengajar_id' => $request->id,
            ]);
        }
        return ['msg'=>'Berhasil menambahkan absen'];
    }

    public function statusPresensiSiswa(Request $request) {
        if($request->status == 1) {
            Presensi::where('mengajar_id', $request->id)->update(['status' => 1]);
            return ['msg' => 'Absen dibuka'];
        } else {
            Presensi::where('mengajar_id', $request->id)->update(['status' => 0]);
            return ['msg' => 'Absen ditutup'];
        }
    }
}
