<?php

namespace App\Http\Controllers\API;

use App\Models\User;
use App\Models\Dosen;
use App\Models\Riwayat;
use App\Models\Tagihan;
use App\Models\Fakultas;
use Illuminate\Http\Request;
use App\Models\RegistrasiUlang;
use App\Http\Controllers\Controller;
use App\Models\RegistrasiMatakuliah;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{
    public function cariSiswa(Request $request) {
        date_default_timezone_set('Asia/Jakarta');
        
        Riwayat::create([
            'user' => 'Admin',
            'kegiatan' => 'Telah mencari data : '.$request->nim,
            'waktu' => date('Y-m-d', time()),
            'status' => 'SUCCESS'
        ]);
        
        return User::with('fakultas')->firstWhere('nim', $request->nim);
    }
    public function updateSiswa(Request $request) {

        $validator = Validator::make($request->all(),[
            'nama_siswa' => 'required|string',
            'ttl_siswa' => 'required|string',
            'agama' => 'required|string',
            'nim' => 'required|string|between:9,9',
            'fakultas' => 'required|string',
            'program_studi' => 'required|string',
            'alamat' => 'required|string',
            'nik' => 'required|string|between:16,16',
            'no_kk' => 'required|string|between:16,16',
            'no_hp' => 'required|string|between:11,12',
            'beban_sks' => 'required|integer',
            'email' => 'required|string|email|max:255',
        ]);

        if($validator->fails()){
            return response()->json($validator->errors());
        }

        $fakultas = Fakultas::where('nama_fakultas', $request->fakultas)->firstWhere('program_studi', $request->program_studi);
        
        try {
            //code...
        } catch (\Exception $e) {
            //throw $th;
        }
        $siswa = User::where('nim',$request->nim)->update([
            'nama_siswa' => $request->nama_siswa,
            'ttl_siswa' => $request->ttl_siswa, 
            'agama' => $request->agama,
            'nim' => $request->nim,
            'alamat' => $request->alamat,
            'nik' => $request->nik,
            'no_kk' => $request->no_kk ,
            'no_hp' => $request->no_hp,
            'email' => $request->email,
            'beban_sks' => $request->beban_sks,
            'fakultas_id' => $fakultas->id,
        ]);

        date_default_timezone_set('Asia/Jakarta');

        Riwayat::create([
            'user' => 'Admin',
            'kegiatan' => 'Telah mengupdate data : '.$request->nim,
            'waktu' => date('Y-m-d', time()),
            'status' => 'SUCCESS'
        ]);
        return response()->json(['message' =>  'Data Berhasil diupdate.']);
    }
    public function updateDosen(Request $request) {

        $validator = Validator::make($request->all(),[
            'nama_dosen' => 'required|string',
            'ttl_dosen' => 'required|string',
            'agama' => 'required|string',
            'nid' => 'required|string|between:5,5',
            'fakultas' => 'required|string',
            'program_studi' => 'required|string',
            'alamat' => 'required|string',
            'nik' => 'required|string|between:16,16',
            'no_kk' => 'required|string|between:16,16',
            'no_hp' => 'required|string|between:11,12',
            'email' => 'required|string|email|max:255',
        ]);

        if($validator->fails()){
            return response()->json($validator->errors());       
        }

        $fakultas = Fakultas::where('nama_fakultas', $request->fakultas)->firstWhere('program_studi', $request->program_studi);

        $dosen = Dosen::where('nid',$request->nid)->update([
            'nama_dosen' => $request->nama_dosen,
            'ttl_dosen' => $request->ttl_dosen, 
            'agama' => $request->agama,
            'nid' => $request->nid,
            'alamat' => $request->alamat,
            'nik' => $request->nik,
            'no_kk' => $request->no_kk,
            'no_hp' => $request->no_hp,
            'email' => $request->email,
            'fakultas_id' => $fakultas->id,
        ]);
        
        date_default_timezone_set('Asia/Jakarta');

        Riwayat::create([
            'user' => 'Admin',
            'kegiatan' => 'Telah mengupdate data : '.$request->nim,
            'waktu' => date('Y-m-d', time()),
            'status' => 'SUCCESS'
        ]);
        return response()->json(['message' => 'Data Berhasil diupdate.']);
    }
    
    public function hapusSiswa(Request $request) {
        $siswa = User::where('nim', $request->nim);
        
        if(!$siswa->delete()) {
            return response()->json(['message' => 'NIM tidak ditemukan']);
        }
        date_default_timezone_set('Asia/Jakarta');
        
        Riwayat::create([
            'user' => 'Admin',
            'kegiatan' => 'Telah menghapus data : '.$request->nim,
            'waktu' => date('Y-m-d', time()),
            'status' => 'SUCCESS'
        ]);
        return response()->json(['message' => 'Data Berhasil dihapus.']);
    }

    public function cariDosen(Request $request) {
        date_default_timezone_set('Asia/Jakarta');
        
        Riwayat::create([
            'user' => 'Admin',
            'kegiatan' => 'Telah mencari data : '.$request->nid,
            'waktu' => date('Y-m-d', time()),
            'status' => 'SUCCESS'
        ]);
        
        return Dosen::with('fakultas')->firstWhere('nid', $request->nid);
    }

    public function hapusDosen(Request $request) {
        $dosen = Dosen::where('nid', $request->nid);
        
        if(!$dosen->delete()) {
            return response()->json(['message' => 'NID tidak ditemukan']);
        }
        date_default_timezone_set('Asia/Jakarta');
        
        Riwayat::create([
            'user' => 'Admin',
            'kegiatan' => 'Telah menghapus data : '.$request->nid,
            'waktu' => date('Y-m-d', time()),
            'status' => 'SUCCESS'
        ]);

        return response()->json(['message' => 'Data Berhasil dihapus.']);
    }

    public function ambilRiwayat(Request $request) {
        return Riwayat::latest()->take(25)->get();
    }

    public function tampilTA (Request $request) {

        return TahunAjar::first();
    }

    public function updateTA (Request $request) {

        
        $validator = Validator::make($request->all(),[
            'semester' => 'required|integer',
            'tahun_ajar' => 'required|string',
        ]);

        if($validator->fails()){
            return response()->json($validator->errors());       
        }

        $tahunAjar = TahunAjar::first()->update([

            'semester' => $request->semester,
            'tahun_ajar' => $request->tahun_ajar,

        ]);

        date_default_timezone_set('Asia/Jakarta');
        
        Riwayat::create([
            'user' => 'Admin',
            'kegiatan' => 'Telah mengganti Tahun Ajaran : Semester'.$request->semester.'dan Tahun Ajar'.$request->tahun_ajar,
            'waktu' => date('Y-m-d', time()),
            'status' => 'SUCCESS'
        ]);
        
        return response()->json(['message'=> 'Data Berhasil diubah.']);

    }

    public function updateTagihan (Request $request){

        $validator = Validator::make($request->all(),[
            'uang_kuliah' => 'required|integer',
            'uang_spp' => 'required|integer',
            'uang_denda' => 'required|integer',
            'layanan_kh' => 'required|integer',
            'total_hutang' => 'required|integer',
            'harus_dibayar' => 'required|integer',
            'sudah_dibayar' => 'required|integer',
        ]);

        if($validator->fails()){
            return response()->json($validator->errors());
        }
        $siswa = User::firstWhere('nim', $request->nim);
        
        Tagihan::where('user_id', $siswa->id)
        ->firstWhere('tahun_ajar_id', $siswa->tahun_ajar_id)
        ->update([
            'uang_kuliah' => $request->uang_kuliah,
            'uang_spp' => $request->uang_spp,
            'uang_denda' => $request->uang_denda,
            'layanan_kh' => $request->layanan_kh,
            'total_hutang' => $request->total_hutang,
            'harus_dibayar' => $request->harus_dibayar,
            'sudah_dibayar' => $request->sudah_dibayar,
        ]);

       return response()->json(['message' => 'Data Berhasil diupdate.']);
    }

    public function cariTagihanSiswa(Request $request) {
        $siswa = User::firstWhere('nim', $request->nim);
        
        return Tagihan::where('user_id', $siswa->id)
        ->firstWhere('tahun_ajar_id', $siswa->tahun_ajar_id);
    }

    public function cariRegisMatkul(Request $request) {
        $validator = Validator::make($request->all(), [
            'nama_fakultas' => 'required|string',
            'program_studi' => 'required|string',
        ]);
        if($validator->fails()){
            return response()->json($validator->errors());
        }

        $fakultas_id = Fakultas::where('nama_fakultas', $request->nama_fakultas)->firstWhere('program_studi', $request->program_studi)->id;

        return RegistrasiMatakuliah::firstWhere('fakultas_id', $fakultas_id);
    }

    public function jadwalRegistrasiMatakuliah(Request $request) {
        $fakultas_id = Fakultas::where('nama_fakultas', $request->nama_fakultas)->firstWhere('program_studi', $request->program_studi)->id;

        $validator = Validator::make($request->all(), [
            'waktu_mulai' => 'required|date',
            'waktu_berakhir' => 'required|date',
        ]); 
        if($validator->fails()){
            return response()->json($validator->errors());
        }
        
        RegistrasiMatakuliah::firstWhere('fakultas_id', $fakultas_id)->update([
            'waktu_mulai' => $request->waktu_mulai,
            'waktu_berakhi'=> $request->waktu_berakhir,
            'fakultas_id' => $fakultas_id,
        ]);
        
        return ['msg'=>'Berhasil mengubah jadwal registrasi matakuliah..!'];
    }
    

    public function jadwalRegistrasiUlang(Request $request){
        $validator = Validator::make($request->all(), [
            'waktu_mulai' => 'required|date',
            'waktu_berakhir' => 'required|date',
        ]); 
        if($validator->fails()){
            return response()->json($validator->errors());
        }
        
        RegistrasiUlang::query()->update([
            'waktu_mulai' => $request->waktu_mulai,
            'waktu_berakhir' => $request->waktu_berakhir,
        ]);

        return ['msg' => 'Berhasil mengubah jadwal registrasi ulang'];
    }


    
}
