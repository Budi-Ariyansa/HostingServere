<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PDF</title>
    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <style>
        table 
        tr th {
            font-size: 14px;
        }
        table 
        tr td {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <?php
            setlocale(LC_ALL, 'IND');
        ?>
        <p class="text-right"><?php echo e(strftime("%A %e %B %Y")); ?></p>
        <center>
            <h3><strong>Tagihan Pembayaran</strong></h3>
            <p>Semester <?php echo e(auth()->user()->tahun_ajar->semester); ?> Tahun <?php echo e(auth()->user()->tahun_ajar->tahun_ajar); ?></p>
        </center>

        <table class="table table-borderless">
            <tr>
                <td width="10%">NIM</td>
                <td width="5%">:</td>
                <td align="left"><?php echo e(auth()->user()->nim); ?></td>
            </tr>
            <tr>
                <td width="10%">Nama</td>
                <td width="2%">:</td>
                <td align="left"><?php echo e(strtoupper(auth()->user()->nama_siswa)); ?></td>
            </tr>
            <tr>
                <td width="10%">Fakultas</td>
                <td width="2%">:</td>
                <td align="left"><?php echo e(strtoupper(auth()->user()->fakultas->nama_fakultas)); ?></td>
            </tr>
            <tr>
                <td width="10%">Jurusan</td>
                <td width="2%">:</td>
                <td align="left"><?php echo e(strtoupper(auth()->user()->fakultas->program_studi)); ?></td>
            </tr>
        </table>

        <table class="table table-borderless mt-2">
            <thead style="border-top: 1px solid black; border-bottom: 1px solid black;">
                <tr>
                    <th width="5%">No</th>
                    <th width="40%">Item Tagihan</th>
                    <th width="5%"></th>
                    <th width="40%">Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1.</td>
                    <td>Uang Kuliah</td>
                    <td>Rp.</td>
                    <td><?php echo e($tagihan->uang_kuliah); ?></td>
                </tr>
                <tr>
                    <td>2.</td>
                    <td>Denda</td>
                    <td>Rp.</td>
                    <td><?php echo e($tagihan->uang_denda); ?></td>
                </tr>
                <tr>
                    <td>3.</td>
                    <td>SPP / BPP</td>
                    <td>Rp.</td>
                    <td><?php echo e($tagihan->uang_spp); ?></td>
                </tr>
                <tr style="border-bottom: 1px solid black">
                    <td>4.</td>
                    <td>Layanan Kemahasiswaan</td>
                    <td>Rp.</td>
                    <td><?php echo e($tagihan->layanan_kh); ?></td>
                </tr>
                <tr>
                    <td></td>
                    <td align="right">Total Tagihan</td>
                    <td>Rp.</td>
                    <td><?php echo e($tagihan->total_hutang); ?></td>
                </tr>
                <tr>
                    <td></td>
                    <td align="right">Terbayar</td>
                    <td>Rp.</td>
                    <td style="border-bottom: 1px solid black"><?php echo e($tagihan->sudah_dibayar); ?></td>
                </tr>
                <tr>
                    <td></td>
                    <td align="right">Sisa Tagihan yang harus dibayar</td>
                    <td>Rp.</td>
                    <td><?php echo e($tagihan->harus_dibayar); ?></td>
                </tr>
            </tbody>
        </table>

        <table class=""table table-borderless>
            <tr>
                <td>Keterangan :</td>
            </tr>
            <tr>
                <td># Jatuh Tempo Pembayaram Registrasi</td>
                <td><?php echo e($tagihan->jatuh_tempo); ?></td>
            </tr>
            <tr>
                <td># Pembayaran pelunasan dilakukan setelah SIASAT</td>
            </tr>
            <tr>
                <td># Jatuh Tempo pembayaran pelunasan </td>
                <td><?php echo e($tagihan->tempo_pelunasan); ?></td>
            </tr>
            <tr>
                <td># Tagihan diatas belum termasuk denda keterlambatan</td>
            </tr>
            <tr>
                <td># Harga per SKS Rp.</td>
                <td><?php echo e($harga_sks); ?><td>
            </tr>
        </table>
    </div>
</body>
</html><?php /**PATH D:\Study\Materi Matkul\Materi 6\SISTER\Project API\siakad-api\resources\views/cetak-tagihan.blade.php ENDPATH**/ ?>