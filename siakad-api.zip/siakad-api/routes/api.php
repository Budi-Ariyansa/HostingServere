<?php

use App\Models\User;
use App\Models\Dosen;
use App\Models\Riwayat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\AdminController;
use App\Http\Controllers\API\DosenController;
use App\Http\Controllers\API\SiswaController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//API route for login user
Route::post('/login-siswa', [AuthController::class, 'loginSiswa']);
Route::post('/login-dosen', [AuthController::class, 'loginDosen']);
Route::post('/login-admin', [AuthController::class, 'loginAdmin']);

//Protecting Routes
Route::group(['middleware' => ['auth:sanctum']], function () {
    
    #SISWA
    Route::get('/profile-siswa', [SiswaController::class, 'profileSiswa']);
    Route::post('/update-profile-beranda', [SiswaController::class, 'updateProfileBeranda']);
    Route::get('/data-semua-siswa', [SiswaController::class, 'semuaDataSiswa']);
    Route::post('/registrasi-ulang', [SiswaController::class, 'registrasiUlang']);
    Route::get('/status-registrasi-ulang', [SiswaController::class, 'statusRegistrasiUlang']);
    Route::get('/kartu-studi-siswa', [SiswaController::class, 'kartuStudiSiswa']);
    Route::post('/hapus-kartu-studi-siswa', [SiswaController::class, 'hapusKelas']);
    Route::get('/status-registrasi-matakuliah', [SiswaController::class, 'statusRegistrasiMatakuliah']);
    Route::get('/jadwal-kuliah', [SiswaController::class, 'jadwalKuliah']);
    Route::get('/registrasi-matakuliah', [SiswaController::class, 'registrasiMatakuliah']);
    Route::post('/registrasi-matakuliah-dalam', [SiswaController::class, 'registrasiMatakuliahDalam']);
    Route::post('/registrasi-matakuliah-kelas-pilihan', [SiswaController::class, 'kelasPilihan']);
    Route::get('/cetak-kartu-studi', [SiswaController::class, 'cetakKST']);
    Route::get('/tagihan-siswa', [SiswaController::class, 'tagihanSiswa']);
    Route::post('/presensi-siswa', [SiswaController::class, 'presensiSiswa']);
    Route::post('/hadir-presensi-siswa', [SiswaController::class, 'presensiHadir']);
    Route::get('/cetak-tagihan', [SiswaController::class, 'cetakTagihan']);
    Route::get('/hasil-studi', [SiswaController::class, 'hasilStudi']);
    Route::get('/transkip-nilai', [SiswaController::class, 'transkipSiswa']);
    Route::post('/request-matakuliah', [SiswaController::class, 'requestMatkul']);

    #DOSEN
    Route::get('/profile-dosen', [DosenController::class, 'profileDosen']);
    Route::get('/jadwal-dosen', [DosenController::class, 'jadwalDosen']);
    Route::post('/buat-presensi-siswa', [DosenController::class, 'buatPresensi']);
    Route::post('/list-presensi-siswa', [DosenController::class, 'listPresensi']);
    Route::post('/status-presensi-siswa', [DosenController::class, 'statusPresensiSiswa']);

    #ADMIN
    Route::post('/cari-siswa', [AdminController::class, 'cariSiswa']);
    Route::post('/hapus-siswa', [AdminController::class, 'hapusSiswa']);
    Route::post('/cari-dosen', [AdminController::class, 'cariDosen']);
    Route::post('/hapus-dosen', [AdminController::class, 'hapusDosen']);
    Route::get('/ambil-riwayat', [AdminController::class, 'ambilRiwayat']);
    Route::post('/tambah-siswa', [AuthController::class, 'tambahSiswa']);
    Route::post('/tambah-dosen', [AuthController::class, 'tambahDosen']);
    Route::post('/update-siswa',[AdminController::class, 'updateSiswa']);
    Route::post('/update-dosen',[AdminController::class, 'updateDosen']);
    Route::post('/tampil-TA',[AdminController::class, 'tampilTA']);
    Route::post('/update-TA',[AdminController::class, 'updateTA']);
    Route::post('/cari-tagihan', [AdminController::class, 'cariTagihanSiswa']);
    Route::post('/update-tagihan-siswa', [AdminController::class, 'updateTagihan']);
    Route::post('/cari-registrasi-matakuliah', [AdminController::class, 'cariRegisMatkul']);
    Route::post('/jadwal-registrasi-matakuliah', [AdminController::class, 'jadwalRegistrasiMatakuliah']);
    Route::post('/jadwal-registrasi-ulang', [AdminController::class, 'jadwalRegistrasiUlang']);

    // API route for logout user
    Route::post('/logout', [AuthController::class, 'logout']);
});
