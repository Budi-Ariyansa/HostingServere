<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('presensis', function (Blueprint $table) {
            $table->id();
            $table->string('nama_pertemuan');
            $table->string('link_meet');
            $table->string('link_materi');
            $table->string('jam_masuk')->default('');
            $table->string('rps_materi');
            $table->integer('status')->default(1);
            $table->foreignId('mengajar_id');
            $table->foreignId('jadwal_kuliah_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('presensis');
    }
};
